
    (() => {
      "use strict";

      const canvas = document.getElementById("gameCanvas");
      const ctx = canvas.getContext("2d");

      const ui = {
        menu: document.getElementById("menuScreen"),
        hud: document.getElementById("hud"),
        playBtn: document.getElementById("playBtn"),
        pauseBtn: document.getElementById("pauseBtn"),
        pauseOverlay: document.getElementById("pauseOverlay"),
        resumeBtn: document.getElementById("resumeBtn"),
        restartBtn: document.getElementById("restartBtn"),
        gameOverOverlay: document.getElementById("gameOverOverlay"),
        retryBtn: document.getElementById("retryBtn"),
        backMenuBtn1: document.getElementById("backMenuBtn1"),
        victoryOverlay: document.getElementById("victoryOverlay"),
        playAgainBtn: document.getElementById("playAgainBtn"),
        backMenuBtn2: document.getElementById("backMenuBtn2"),
        transitionOverlay: document.getElementById("transitionOverlay"),
        transitionText: document.getElementById("transitionText"),
        lifeFill: document.getElementById("lifeFill"),
        lifeText: document.getElementById("lifeText"),
        scoreText: document.getElementById("scoreText"),
        coinText: document.getElementById("coinText"),
        phaseText: document.getElementById("phaseText"),
      };

      const W = canvas.width;
      const H = canvas.height;
      const GROUND_Y = 620;
      const keys = {};
      let lastTime = 0;

      const game = {
        running: false,
        paused: false,
        state: "menu",
        levelIndex: 0,
        score: 0,
        coins: 0,
        camera: { x: 0, y: 0, shake: 0, shakeMag: 0 },
        particles: [],
        hitEffects: [],
        player: null,
        enemies: [],
        platforms: [],
        collectibles: [],
        decorations: [],
        exit: null,
        bossDefeated: false,
        transitioning: false,
      };

      function clamp(v, min, max) { return Math.max(min, Math.min(max, v)); }
      function lerp(a,b,t){ return a + (b-a)*t; }
      function rand(min,max){ return Math.random()*(max-min)+min; }
      function rectsIntersect(a,b){
        return a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;
      }

      function createAudioSystem(){
        let ac = null;
        let enabled = false;

        function init(){
          if(enabled) return;
          try{
            ac = new (window.AudioContext || window.webkitAudioContext)();
            enabled = true;
          }catch(e){}
        }

        function tone(type, freq, duration, volume=.03, when=0){
          if(!ac) return;
          const t = ac.currentTime + when;
          const osc = ac.createOscillator();
          const gain = ac.createGain();
          osc.type = type;
          osc.frequency.setValueAtTime(freq, t);
          gain.gain.setValueAtTime(0.0001, t);
          gain.gain.exponentialRampToValueAtTime(volume, t + 0.01);
          gain.gain.exponentialRampToValueAtTime(0.0001, t + duration);
          osc.connect(gain).connect(ac.destination);
          osc.start(t);
          osc.stop(t + duration + 0.02);
        }

        return {
          init,
          collect(){ tone("triangle", 1046, .12, .035); tone("triangle", 1318, .14, .02, .03); },
          crystal(){ tone("sine", 880, .15, .04); tone("sine", 1760, .18, .02, .04); },
          heal(){ tone("sine", 620, .15, .03); tone("triangle", 880, .18, .02, .04); },
          hit(){ tone("square", 180, .07, .05); tone("triangle", 120, .08, .03, .01); },
          damage(){ tone("sawtooth", 150, .12, .04); },
          enemyDown(){ tone("triangle", 280, .12, .03); tone("triangle", 180, .2, .03, .05); },
          jump(){ tone("square", 320, .07, .025); },
          win(){ tone("triangle", 523, .14, .035); tone("triangle", 659, .14, .03, .12); tone("triangle", 784, .24, .03, .24); },
          phase(){ tone("sine", 440, .1, .03); tone("sine", 660, .14, .03, .1); },
          gameOver(){ tone("sawtooth", 392, .18, .045); tone("sawtooth", 294, .22, .04, .16); tone("sawtooth", 196, .4, .045, .34); },
          click(){ tone("square", 520, .05, .025); tone("square", 760, .05, .015, .04); },
          pause(){ tone("sine", 300, .1, .025); },
          resume(){ tone("sine", 420, .1, .025); },
        };
      }
      const audio = createAudioSystem();

      function createPlayer(x, y){
        return {
          x, y, w: 34, h: 52,
          vx: 0, vy: 0,
          speed: 260,
          jump: 520,
          onGround: false,
          facing: 1,
          hp: 100, maxHp: 100,
          hurtTimer: 0,
          attackTimer: 0,
          attackCooldown: 0,
          state: "idle",
          frameTime: 0,
          animFrame: 0,
          invuln: 0,
          victoryTimer: 0,
        };
      }

      function levelData(){
        return [
          {
            name: "Fase 1",
            theme: "forest",
            worldWidth: 2400,
            playerStart: {x: 100, y: 520},
            exit: {x: 2270, y: 540, w: 60, h: 80},
            platforms: [
              {x: 220, y: 560, w: 170, h: 18},
              {x: 470, y: 500, w: 160, h: 18},
              {x: 700, y: 450, w: 150, h: 18},
              {x: 950, y: 530, w: 180, h: 18},
              {x: 1260, y: 470, w: 190, h: 18},
              {x: 1540, y: 430, w: 140, h: 18},
              {x: 1740, y: 500, w: 180, h: 18},
              {x: 1990, y: 455, w: 120, h: 18},
            ],
            enemies: [
              {x: 560, y: 462, type:"wolf", hp:30, speed:55, damage:10},
              {x: 1020, y: 492, type:"boar", hp:36, speed:45, damage:12},
              {x: 1640, y: 392, type:"wolf", hp:30, speed:60, damage:10},
              {x: 1880, y: 568, type:"snake", hp:24, speed:40, damage:8},
            ],
            collectibles: [
              {x: 280, y: 525, type:"coin"}, {x: 340, y: 525, type:"coin"},
              {x: 520, y: 465, type:"coin"}, {x: 565, y: 465, type:"crystal"},
              {x: 735, y: 415, type:"coin"}, {x: 790, y: 415, type:"coin"},
              {x: 980, y: 495, type:"potion"},
              {x: 1320, y: 435, type:"coin"}, {x: 1390, y: 435, type:"coin"},
              {x: 1588, y: 395, type:"crystal"},
              {x: 1780, y: 465, type:"coin"}, {x: 1850, y: 465, type:"coin"},
              {x: 2050, y: 420, type:"potion"},
            ],
          },
          {
            name: "Fase 2",
            theme: "darkForest",
            worldWidth: 2900,
            playerStart: {x: 100, y: 520},
            exit: {x: 2780, y: 540, w: 60, h: 80},
            platforms: [
              {x: 260, y: 560, w: 170, h: 18},
              {x: 520, y: 510, w: 140, h: 18},
              {x: 740, y: 455, w: 180, h: 18},
              {x: 1010, y: 390, w: 130, h: 18},
              {x: 1200, y: 520, w: 180, h: 18},
              {x: 1490, y: 470, w: 180, h: 18},
              {x: 1770, y: 420, w: 150, h: 18},
              {x: 1990, y: 520, w: 170, h: 18},
              {x: 2260, y: 450, w: 160, h: 18},
              {x: 2470, y: 390, w: 170, h: 18},
            ],
            enemies: [
              {x: 610, y: 472, type:"wolf", hp:40, speed:65, damage:12},
              {x: 860, y: 417, type:"snake", hp:32, speed:55, damage:10},
              {x: 1300, y: 482, type:"boar", hp:45, speed:50, damage:14},
              {x: 1830, y: 382, type:"wolf", hp:40, speed:70, damage:12},
              {x: 2100, y: 482, type:"snake", hp:34, speed:60, damage:10},
              {x: 2570, y: 332, type:"boss", hp:120, speed:46, damage:18, boss:true},
            ],
            collectibles: [
              {x: 310, y: 525, type:"coin"}, {x: 370, y: 525, type:"coin"},
              {x: 560, y: 475, type:"coin"}, {x: 600, y: 475, type:"potion"},
              {x: 785, y: 420, type:"crystal"},
              {x: 1060, y: 355, type:"coin"}, {x: 1100, y: 355, type:"coin"},
              {x: 1240, y: 485, type:"coin"},
              {x: 1540, y: 435, type:"crystal"},
              {x: 1810, y: 385, type:"coin"},
              {x: 2020, y: 485, type:"potion"},
              {x: 2310, y: 415, type:"coin"},
              {x: 2520, y: 355, type:"coin"}, {x: 2580, y: 355, type:"crystal"},
            ],
          }
        ];
      }

      const LEVELS = levelData();

      function makeDecorations(theme, worldWidth){
        const items = [];
        for(let x=0; x<worldWidth; x+=120){
          items.push({
            kind:"tree",
            x:x + rand(0,50),
            y:GROUND_Y,
            s:rand(.8,1.35),
            depth:Math.random()>.5 ? .6 : .9
          });
        }
        for(let i=0;i<40;i++){
          items.push({ kind:"bush", x:rand(0,worldWidth), y:GROUND_Y + rand(-8,10), s:rand(.6,1.2), depth:.95 });
        }
        for(let i=0;i<36;i++){
          items.push({ kind:"rock", x:rand(20,worldWidth-20), y:GROUND_Y + rand(-4,10), s:rand(.7,1.1), depth:1 });
        }
        for(let i=0;i<64;i++){
          items.push({ kind:"flower", x:rand(20,worldWidth-20), y:GROUND_Y + rand(-4,10), s:rand(.5,.9), depth:1 });
        }
        if(theme === "darkForest"){
          for(let i=0;i<18;i++){
            items.push({ kind:"mist", x:rand(0,worldWidth), y:rand(180,580), s:rand(.8,1.6), depth:.4 });
          }
        }
        return items;
      }

      function buildLevel(index){
        const data = LEVELS[index];
        game.levelIndex = index;
        game.player = createPlayer(data.playerStart.x, data.playerStart.y);
        game.platforms = data.platforms.map(p => ({...p}));
        game.enemies = data.enemies.map(e => ({
          ...e,
          w: e.boss ? 60 : 34,
          h: e.boss ? 66 : 38,
          vx: 0,
          vy: 0,
          dir: -1,
          originX: e.x,
          range: e.boss ? 240 : 110,
          attackCooldown: 0,
          attackTimer: 0,
          hurtTimer: 0,
          alive: true,
          maxHp: e.hp
        }));
        game.collectibles = data.collectibles.map(c => ({
          ...c,
          w: c.type==="potion" ? 18 : 14,
          h: c.type==="potion" ? 20 : 14,
          collected:false,
          bob: rand(0, Math.PI*2)
        }));
        game.decorations = makeDecorations(data.theme, data.worldWidth);
        game.exit = {...data.exit};
        game.worldWidth = data.worldWidth;
        game.theme = data.theme;
        game.bossDefeated = false;
        game.particles.length = 0;
        game.hitEffects.length = 0;
        game.camera.x = 0;
        game.camera.shake = 0;
        updateHUD();
      }

      function resetGame(){
        game.score = 0;
        game.coins = 0;
        buildLevel(0);
        game.state = "playing";
        game.running = true;
        game.paused = false;
        ui.hud.classList.remove("hidden");
        hideAllOverlays();
      }

      function hideAllOverlays(){
        ui.pauseOverlay.classList.remove("show");
        ui.gameOverOverlay.classList.remove("show");
        ui.victoryOverlay.classList.remove("show");
        ui.transitionOverlay.classList.remove("show");
      }

      function updateHUD(){
        const p = game.player;
        ui.lifeFill.style.width = `${(p.hp / p.maxHp) * 100}%`;
        ui.lifeText.textContent = `${Math.max(0,Math.ceil(p.hp))} / ${p.maxHp}`;
        ui.scoreText.textContent = game.score;
        ui.coinText.textContent = game.coins;
        ui.phaseText.textContent = `Fase ${game.levelIndex + 1}`;
      }

      function startLevelTransition(nextIndex){
        game.transitioning = true;
        game.running = false;
        audio.phase();
        ui.transitionText.textContent = nextIndex < LEVELS.length
          ? `A floresta muda... entrando na Fase ${nextIndex + 1}.`
          : `A paz retorna à floresta.`;
        ui.transitionOverlay.classList.add("show");

        setTimeout(() => {
          ui.transitionOverlay.classList.remove("show");
          if(nextIndex < LEVELS.length){
            buildLevel(nextIndex);
            game.running = true;
            game.state = "playing";
          }else{
            game.state = "victory";
            game.running = false;
            game.player.state = "victory";
            ui.victoryOverlay.classList.add("show");
            audio.win();
          }
          game.transitioning = false;
        }, 1400);
      }

      function gameOver(){
        game.running = false;
        game.state = "gameover";
        ui.gameOverOverlay.classList.add("show");
        audio.gameOver();
      }

      function togglePause(force){
        if(game.state !== "playing") return;
        game.paused = typeof force === "boolean" ? force : !game.paused;
        game.running = !game.paused;
        audio.init();
        game.paused ? audio.pause() : audio.resume();
        ui.pauseOverlay.classList.toggle("show", game.paused);
      }

      function screenToWorld(x){ return x + game.camera.x; }

      function updatePlayer(dt){
        const p = game.player;
        const left = keys["ArrowLeft"] || keys["KeyA"];
        const right = keys["ArrowRight"] || keys["KeyD"];
        const jump = keys["ArrowUp"] || keys["KeyW"] || keys["Space"];
        const attack = keys["Digit1"] || keys["Numpad1"];

        let move = 0;
        if(left) move -= 1;
        if(right) move += 1;

        const accel = p.onGround ? 1800 : 1100;
        const maxSpeed = p.speed;
        const target = move * maxSpeed;
        p.vx = lerp(p.vx, target, clamp(accel * dt / maxSpeed, 0, 1));

        if(move === 0){
          p.vx *= p.onGround ? 0.82 : 0.98;
          if(Math.abs(p.vx) < 4) p.vx = 0;
        }

        if(move !== 0) p.facing = move > 0 ? 1 : -1;

        if(jump && p.onGround){
          p.vy = -p.jump;
          p.onGround = false;
          audio.jump();
        }

        p.vy += 1200 * dt;
        p.vy = Math.min(p.vy, 760);

        p.x += p.vx * dt;
        resolveHorizontalCollisions(p);

        p.y += p.vy * dt;
        resolveVerticalCollisions(p);

        p.x = clamp(p.x, 0, game.worldWidth - p.w);

        if(p.y > H + 220){
          p.hp = 0;
        }

        if(attack && p.attackCooldown <= 0){
          p.attackTimer = 0.18;
          p.attackCooldown = 0.34;
          p.state = "attack";
          playerAttack();
        }

        if(p.attackTimer > 0) p.attackTimer -= dt;
        if(p.attackCooldown > 0) p.attackCooldown -= dt;
        if(p.hurtTimer > 0) p.hurtTimer -= dt;
        if(p.invuln > 0) p.invuln -= dt;

        if(game.state === "victory"){
          p.vx = 0;
          p.state = "victory";
          p.victoryTimer += dt;
        } else if(p.hurtTimer > 0){
          p.state = "hurt";
        } else if(p.attackTimer > 0){
          p.state = "attack";
        } else if(!p.onGround){
          p.state = "jump";
        } else if(Math.abs(p.vx) > 20){
          p.state = "walk";
        } else {
          p.state = "idle";
        }

        animatePlayer(p, dt);

        if(p.hp <= 0){
          gameOver();
        }
      }

      function animatePlayer(p, dt){
        p.frameTime += dt;
        const speed = p.state === "walk" ? 0.09 : p.state === "attack" ? 0.07 : 0.14;
        if(p.frameTime >= speed){
          p.frameTime = 0;
          p.animFrame = (p.animFrame + 1) % (p.state === "walk" ? 4 : 2);
        }
      }

      function resolveHorizontalCollisions(e){
        for(const pf of game.platforms){
          if(rectsIntersect(e, pf)){
            if(e.vx > 0) e.x = pf.x - e.w;
            else if(e.vx < 0) e.x = pf.x + pf.w;
            e.vx = 0;
          }
        }
      }

      function resolveVerticalCollisions(e){
        e.onGround = false;

        if(e.y + e.h >= GROUND_Y){
          e.y = GROUND_Y - e.h;
          e.vy = 0;
          e.onGround = true;
        }

        for(const pf of game.platforms){
          if(rectsIntersect(e, pf)){
            const prevBottom = e.y + e.h - e.vy * 0.016;
            const prevTop = e.y - e.vy * 0.016;
            if(prevBottom <= pf.y + 8 && e.vy >= 0){
              e.y = pf.y - e.h;
              e.vy = 0;
              e.onGround = true;
            }else if(prevTop >= pf.y + pf.h - 8 && e.vy < 0){
              e.y = pf.y + pf.h;
              e.vy = 30;
            }
          }
        }
      }

      function playerAttack(){
        const p = game.player;
        const hitbox = {
          x: p.facing > 0 ? p.x + p.w - 2 : p.x - 32,
          y: p.y + 10,
          w: 34,
          h: 28
        };

        let hitSomething = false;

        for(const e of game.enemies){
          if(!e.alive) continue;
          if(rectsIntersect(hitbox, e)){
            e.hp -= e.boss ? 12 : 18;
            e.hurtTimer = 0.18;
            e.vx += p.facing * 120;
            spawnHitEffect(e.x + e.w/2, e.y + e.h/2, "#d6ff7a");
            audio.hit();
            hitSomething = true;

            if(e.hp <= 0){
              e.alive = false;
              game.score += e.boss ? 350 : 120;
              if(e.boss) game.bossDefeated = true;
              spawnBurst(e.x + e.w/2, e.y + e.h/2, e.boss ? 26 : 14, e.boss ? "#b4ff7a" : "#88ffbf");
              audio.enemyDown();
            }
          }
        }

        if(hitSomething) updateHUD();
      }

      function damagePlayer(amount){
        const p = game.player;
        if(p.invuln > 0) return;
        p.hp -= amount;
        p.hurtTimer = 0.28;
        p.invuln = 0.7;
        game.camera.shake = 0.28;
        game.camera.shakeMag = 8;
        spawnBurst(p.x + p.w/2, p.y + p.h/2, 10, "#ff8d8d");
        audio.damage();
        updateHUD();
      }

      function updateEnemies(dt){
        const p = game.player;

        for(const e of game.enemies){
          if(!e.alive) continue;

          e.vy = (e.vy || 0) + 1200 * dt;
          const dx = (p.x + p.w/2) - (e.x + e.w/2);
          const dy = Math.abs((p.y + p.h/2) - (e.y + e.h/2));
          const close = Math.abs(dx) < (e.boss ? 260 : 160) && dy < 100;

          if(e.attackCooldown > 0) e.attackCooldown -= dt;
          if(e.attackTimer > 0) e.attackTimer -= dt;
          if(e.hurtTimer > 0) e.hurtTimer -= dt;

          if(close){
            e.dir = dx > 0 ? 1 : -1;
            const desired = e.dir * e.speed;
            e.vx = lerp(e.vx, desired, 0.06);
            if(Math.abs(dx) < (e.boss ? 60 : 40) && e.attackCooldown <= 0){
              e.attackTimer = 0.24;
              e.attackCooldown = e.boss ? 1.0 : 1.2;
              damagePlayer(e.damage);
            }
          }else{
            const leftBound = e.originX - e.range;
            const rightBound = e.originX + e.range;
            if(e.x <= leftBound) e.dir = 1;
            if(e.x + e.w >= rightBound) e.dir = -1;
            e.vx = lerp(e.vx, e.dir * e.speed * 0.55, 0.03);
          }

          e.x += e.vx * dt;
          resolveHorizontalCollisions(e);
          e.y += e.vy * dt;
          resolveVerticalCollisions(e);

          if(rectsIntersect(p, e) && e.attackCooldown <= 0 && p.invuln <= 0){
            e.attackCooldown = 1;
            damagePlayer(e.damage);
          }
        }
      }

      function updateCollectibles(dt){
        const p = game.player;
        for(const c of game.collectibles){
          if(c.collected) continue;
          c.bob += dt * 3;
          const hit = {
            x:c.x, y:c.y + Math.sin(c.bob)*4, w:c.w, h:c.h
          };
          if(rectsIntersect(p, hit)){
            c.collected = true;
            if(c.type === "coin"){
              game.coins += 1;
              game.score += 25;
              spawnBurst(c.x + c.w/2, c.y + c.h/2, 10, "#ffd966");
              audio.collect();
            }else if(c.type === "potion"){
              p.hp = Math.min(p.maxHp, p.hp + 28);
              game.score += 40;
              spawnBurst(c.x + c.w/2, c.y + c.h/2, 10, "#7dffb1");
              audio.heal();
            }else if(c.type === "crystal"){
              game.score += 90;
              spawnBurst(c.x + c.w/2, c.y + c.h/2, 14, "#84ff6d");
              audio.crystal();
            }
            updateHUD();
          }
        }
      }

      function updateExit(){
        const p = game.player;
        if(game.levelIndex === 0){
          if(rectsIntersect(p, game.exit)){
            startLevelTransition(1);
          }
        }else{
          const bossAlive = game.enemies.some(e => e.boss && e.alive);
          if(!bossAlive && rectsIntersect(p, game.exit)){
            startLevelTransition(2);
          }
        }
      }

      function spawnBurst(x, y, count, color){
        for(let i=0;i<count;i++){
          game.particles.push({
            x, y,
            vx: rand(-140, 140),
            vy: rand(-180, 40),
            life: rand(.35, .8),
            maxLife: 1,
            size: rand(2,5),
            color
          });
        }
      }

      function spawnHitEffect(x,y,color){
        game.hitEffects.push({x,y,life:.14,color});
      }

      function updateParticles(dt){
        game.particles = game.particles.filter(p => {
          p.life -= dt;
          p.x += p.vx * dt;
          p.y += p.vy * dt;
          p.vy += 340 * dt;
          return p.life > 0;
        });

        game.hitEffects = game.hitEffects.filter(h => {
          h.life -= dt;
          return h.life > 0;
        });
      }

      function updateCamera(dt){
        const p = game.player;
        const targetX = clamp(p.x - W * 0.35, 0, game.worldWidth - W);
        game.camera.x = lerp(game.camera.x, targetX, 0.09);

        if(game.camera.shake > 0){
          game.camera.shake -= dt;
        }
      }

      function update(dt){
        if(!game.running || game.paused || game.state !== "playing") return;
        updatePlayer(dt);
        updateEnemies(dt);
        updateCollectibles(dt);
        updateExit();
        updateParticles(dt);
        updateCamera(dt);
      }

      function clear(){
        ctx.clearRect(0,0,W,H);
      }

      function drawBackground(){
        if(game.theme === "forest"){
          const g = ctx.createLinearGradient(0,0,0,H);
          g.addColorStop(0,"#9ce7ff");
          g.addColorStop(.35,"#7dc9b6");
          g.addColorStop(1,"#214126");
          ctx.fillStyle = g;
        }else{
          const g = ctx.createLinearGradient(0,0,0,H);
          g.addColorStop(0,"#1a1f39");
          g.addColorStop(.45,"#25304d");
          g.addColorStop(1,"#141a14");
          ctx.fillStyle = g;
        }
        ctx.fillRect(0,0,W,H);

        // Sol/Lua
        ctx.save();
        if(game.theme === "forest"){
          ctx.fillStyle = "rgba(255,245,190,.95)";
          ctx.beginPath(); ctx.arc(1020 - game.camera.x*0.15, 110, 42, 0, Math.PI*2); ctx.fill();
        }else{
          ctx.fillStyle = "rgba(220,235,255,.9)";
          ctx.beginPath(); ctx.arc(1040 - game.camera.x*0.12, 110, 38, 0, Math.PI*2); ctx.fill();
        }
        ctx.restore();

        // Camadas de floresta
        for(let layer=0;layer<3;layer++){
          const depth = 0.15 + layer * 0.12;
          ctx.fillStyle = layer === 0
            ? (game.theme==="forest" ? "#315a35" : "#1d2c28")
            : layer === 1
            ? (game.theme==="forest" ? "#214629" : "#16211e")
            : (game.theme==="forest" ? "#17361f" : "#101916");

          for(let i=0;i<18;i++){
            const x = ((i*160) - game.camera.x*depth) % (W+180) - 120;
            const h = 140 + ((i*37 + layer*19) % 120);
            drawTriangleTree(x, GROUND_Y - 90 - layer*35, 90, h);
          }
        }

        // Névoa leve
        if(game.theme === "darkForest"){
          ctx.fillStyle = "rgba(210,240,255,.05)";
          for(let i=0;i<7;i++){
            const x = ((i*240) - game.camera.x*0.18 + (performance.now()*0.01*(i%2?1:-1))) % (W+300) - 150;
            ctx.beginPath();
            ctx.ellipse(x, 500 - i*20, 180, 38, 0, 0, Math.PI*2);
            ctx.fill();
          }
        }
      }

      function drawTriangleTree(x, y, w, h){
        ctx.beginPath();
        ctx.moveTo(x + w/2, y - h);
        ctx.lineTo(x, y);
        ctx.lineTo(x + w, y);
        ctx.closePath();
        ctx.fill();

        ctx.fillStyle = "#402d18";
        ctx.fillRect(x + w/2 - 6, y, 12, 28);
      }

      function drawDecorations(){
        for(const d of game.decorations){
          const x = d.x - game.camera.x * d.depth;
          const sway = Math.sin(performance.now()*0.001 + d.x*.01) * 1.5;

          if(d.kind === "tree"){
            const h = 110 * d.s;
            ctx.fillStyle = game.theme === "forest" ? "#4b321d" : "#342317";
            ctx.fillRect(x, d.y - h, 14*d.s, h);
            ctx.fillStyle = game.theme === "forest" ? "#2f6a36" : "#203326";
            pixelBlob(x - 34*d.s + sway, d.y - h + 8, 80*d.s, 60*d.s);
            ctx.fillStyle = game.theme === "forest" ? "#3e8446" : "#2a4635";
            pixelBlob(x - 24*d.s - sway, d.y - h - 18, 58*d.s, 42*d.s);
          } else if(d.kind === "bush"){
            ctx.fillStyle = game.theme === "forest" ? "#2f793b" : "#274233";
            pixelBlob(x, d.y - 20*d.s, 34*d.s, 22*d.s);
          } else if(d.kind === "rock"){
            ctx.fillStyle = game.theme === "forest" ? "#6c776e" : "#5b6168";
            drawPixelRock(x, d.y - 8*d.s, 18*d.s, 12*d.s);
          } else if(d.kind === "flower"){
            ctx.fillStyle = "#3d9f4d";
            ctx.fillRect(x, d.y - 10*d.s, 2*d.s, 10*d.s);
            ctx.fillStyle = game.theme === "forest" ? "#ffd4ef" : "#b7a6ff";
            ctx.fillRect(x - 2*d.s, d.y - 12*d.s, 6*d.s, 4*d.s);
          } else if(d.kind === "mist"){
            ctx.fillStyle = "rgba(220,240,255,.05)";
            ctx.beginPath();
            ctx.ellipse(x, d.y, 40*d.s, 12*d.s, 0, 0, Math.PI*2);
            ctx.fill();
          }
        }
      }

      function pixelBlob(x,y,w,h){
        ctx.fillRect(x, y, w*.25, h*.35);
        ctx.fillRect(x+w*.2, y-h*.12, w*.28, h*.42);
        ctx.fillRect(x+w*.42, y-h*.06, w*.22, h*.36);
        ctx.fillRect(x+w*.56, y, w*.24, h*.35);
      }

      function drawPixelRock(x,y,w,h){
        ctx.fillRect(x,y,w,h);
        ctx.fillStyle = "rgba(255,255,255,.12)";
        ctx.fillRect(x+2,y+2,w*.35,h*.25);
      }

      function drawGround(){
        ctx.fillStyle = game.theme === "forest" ? "#315b2d" : "#27362a";
        ctx.fillRect(-game.camera.x, GROUND_Y, game.worldWidth, H-GROUND_Y);

        ctx.fillStyle = game.theme === "forest" ? "#467a39" : "#39493b";
        for(let x=0; x<game.worldWidth; x+=36){
          ctx.fillRect(x - game.camera.x, GROUND_Y - ((x/36)%2===0 ? 6:4), 18, 6);
        }
      }

      function drawPlatforms(){
        for(const p of game.platforms){
          const x = p.x - game.camera.x;
          ctx.fillStyle = "#5c4427";
          ctx.fillRect(x, p.y, p.w, p.h);
          ctx.fillStyle = "#7d6039";
          ctx.fillRect(x, p.y, p.w, 4);
          ctx.fillStyle = "#4fa64e";
          for(let i=0;i<p.w;i+=26){
            ctx.fillRect(x+i+4, p.y-4, 10, 4);
          }
        }
      }

      function drawCollectibles(){
        for(const c of game.collectibles){
          if(c.collected) continue;
          const y = c.y + Math.sin(c.bob) * 4;
          const x = c.x - game.camera.x;

          if(c.type === "coin"){
            ctx.fillStyle = "#f4c84f";
            ctx.fillRect(x, y, 14, 14);
            ctx.fillStyle = "#ffe79b";
            ctx.fillRect(x+3, y+3, 8, 8);
          }else if(c.type === "potion"){
            ctx.fillStyle = "#6c4d2a";
            ctx.fillRect(x+6, y, 6, 4);
            ctx.fillStyle = "#6eff9a";
            ctx.fillRect(x+2, y+4, 14, 14);
          }else if(c.type === "crystal"){
            ctx.fillStyle = "#93ff66";
            ctx.beginPath();
            ctx.moveTo(x+7, y);
            ctx.lineTo(x+14, y+7);
            ctx.lineTo(x+7, y+14);
            ctx.lineTo(x, y+7);
            ctx.closePath();
            ctx.fill();
          }
        }
      }

      function drawExit(){
        const x = game.exit.x - game.camera.x;
        const y = game.exit.y;
        ctx.fillStyle = "#2f2418";
        ctx.fillRect(x, y, game.exit.w, game.exit.h);
        ctx.fillStyle = "#6fff95";
        ctx.fillRect(x+18, y+16, 24, 48);

        if(game.levelIndex === 1){
          const bossAlive = game.enemies.some(e => e.boss && e.alive);
          if(bossAlive){
            ctx.fillStyle = "rgba(255,80,80,.75)";
            ctx.fillRect(x-6, y-8, game.exit.w+12, 8);
          }
        }
      }

      function drawEnemy(e){
        const x = Math.round(e.x - game.camera.x);
        const y = Math.round(e.y);

        ctx.save();
        if(e.hurtTimer > 0) ctx.globalAlpha = .7;

        // sombra
        ctx.fillStyle = "rgba(0,0,0,.2)";
        ctx.beginPath();
        ctx.ellipse(x + e.w/2, y + e.h + 4, e.w*.45, 6, 0, 0, Math.PI*2);
        ctx.fill();

        ctx.translate(x + e.w/2, y + e.h/2);
        ctx.scale(e.dir, 1);
        ctx.translate(-e.w/2, -e.h/2);

        if(e.type === "wolf"){
          ctx.fillStyle = "#6f706d";
          ctx.fillRect(4, 10, 22, 14);
          ctx.fillRect(20, 12, 10, 10);
          ctx.fillStyle = "#8d8f8b";
          ctx.fillRect(8, 6, 14, 10);
          ctx.fillStyle = "#d95b5b";
          if(e.attackTimer > 0) ctx.fillRect(26, 18, 6, 3);
          for(let i=0;i<4;i++) ctx.fillRect(6+i*6, 24, 3, 10);
        }else if(e.type === "boar"){
          ctx.fillStyle = "#7a4d31";
          ctx.fillRect(4, 12, 24, 14);
          ctx.fillRect(22, 14, 10, 9);
          ctx.fillStyle = "#d8d1c0";
          ctx.fillRect(28, 18, 4, 2);
          for(let i=0;i<4;i++) ctx.fillRect(7+i*6, 26, 3, 9);
        }else if(e.type === "snake"){
          ctx.fillStyle = "#436a3f";
          ctx.fillRect(6, 18, 16, 10);
          ctx.fillRect(18, 14, 8, 8);
          ctx.fillRect(22, 10, 6, 6);
          ctx.fillStyle = "#b24f6a";
          if(e.attackTimer > 0) ctx.fillRect(28, 13, 6, 2);
        }else if(e.type === "boss"){
          ctx.fillStyle = "#3d2f25";
          ctx.fillRect(8, 18, 34, 20);
          ctx.fillRect(34, 20, 16, 14);
          ctx.fillStyle = "#5b4738";
          ctx.fillRect(12, 10, 22, 14);
          ctx.fillStyle = "#c8d66d";
          ctx.fillRect(40, 24, 6, 3);
          for(let i=0;i<4;i++) ctx.fillRect(12+i*9, 38, 4, 14);
        }

        ctx.restore();

        // barra de vida
        const bw = e.boss ? 68 : 40;
        const bx = x + e.w/2 - bw/2;
        const by = y - 12;
        ctx.fillStyle = "rgba(0,0,0,.45)";
        ctx.fillRect(bx, by, bw, 6);
        ctx.fillStyle = "#ff6f6f";
        ctx.fillRect(bx, by, bw * (e.hp / e.maxHp), 6);
        ctx.strokeStyle = "rgba(255,255,255,.18)";
        ctx.strokeRect(bx, by, bw, 6);
      }

      function drawPlayer(){
        const p = game.player;
        const x = Math.round(p.x - game.camera.x);
        const y = Math.round(p.y);

        if(p.invuln > 0 && Math.floor(p.invuln * 20) % 2 === 0) return;

        // sombra
        ctx.fillStyle = "rgba(0,0,0,.22)";
        ctx.beginPath();
        ctx.ellipse(x + p.w/2, y + p.h + 4, p.w*.46, 6, 0, 0, Math.PI*2);
        ctx.fill();

        ctx.save();
        ctx.translate(x + p.w/2, y + p.h/2);
        ctx.scale(p.facing, 1);
        ctx.translate(-p.w/2, -p.h/2);

        const walkOffset = p.state === "walk" ? [0,1,0,-1][p.animFrame] : 0;

        // capa
        ctx.fillStyle = p.state === "hurt" ? "#345a31" : "#3f7f43";
        ctx.fillRect(7, 12, 18, 32);

        // corpo
        ctx.fillStyle = "#6a4d2b";
        ctx.fillRect(11, 16, 12, 16);

        // cabeça
        ctx.fillStyle = "#d1a067";
        ctx.fillRect(11, 4, 12, 12);

        // cabelo/capuz
        ctx.fillStyle = "#1d2419";
        ctx.fillRect(9, 2, 16, 6);

        // pernas
        ctx.fillStyle = "#3a2816";
        if(p.state === "walk"){
          ctx.fillRect(11, 32, 4, 14 + walkOffset);
          ctx.fillRect(19, 32, 4, 14 - walkOffset);
        }else{
          ctx.fillRect(11, 32, 4, 14);
          ctx.fillRect(19, 32, 4, 14);
        }

        // braço
        ctx.fillStyle = "#d1a067";
        if(p.state === "attack"){
          ctx.fillRect(22, 16, 10, 4);
          ctx.fillStyle = "#9cff70";
          ctx.fillRect(30, 14, 6, 8);
        }else if(p.state === "victory"){
          ctx.fillRect(22, 10, 8, 4);
          ctx.fillStyle = "#9cff70";
          ctx.fillRect(28, 6, 6, 8);
        }else{
          ctx.fillRect(22, 18, 7, 4);
        }

        ctx.restore();

        if(p.state === "attack"){
          ctx.fillStyle = "rgba(156,255,112,.35)";
          const hx = p.facing > 0 ? x + p.w - 2 : x - 28;
          ctx.fillRect(hx, y + 10, 30, 26);
        }
      }

      function drawParticles(){
        for(const p of game.particles){
          ctx.globalAlpha = clamp(p.life / p.maxLife, 0, 1);
          ctx.fillStyle = p.color;
          ctx.fillRect(p.x - game.camera.x, p.y, p.size, p.size);
        }
        ctx.globalAlpha = 1;

        for(const h of game.hitEffects){
          ctx.globalAlpha = h.life / .14;
          ctx.strokeStyle = h.color;
          ctx.lineWidth = 2;
          ctx.beginPath();
          ctx.arc(h.x - game.camera.x, h.y, 10 + (1 - h.life/.14) * 16, 0, Math.PI * 2);
          ctx.stroke();
        }
        ctx.globalAlpha = 1;
      }

      function drawWorld(){
        clear();
        if(game.state === "menu"){
          return;
        }

        let shakeX = 0, shakeY = 0;
        if(game.camera.shake > 0){
          shakeX = rand(-game.camera.shakeMag, game.camera.shakeMag);
          shakeY = rand(-game.camera.shakeMag * .5, game.camera.shakeMag * .5);
        }

        ctx.save();
        ctx.translate(shakeX, shakeY);
        drawBackground();
        drawDecorations();
        drawGround();
        drawPlatforms();
        drawCollectibles();
        drawExit();
        for(const e of game.enemies) if(e.alive) drawEnemy(e);
        drawPlayer();
        drawParticles();
        ctx.restore();
      }

      function render(){
        drawWorld();
      }

      function loop(ts){
        const dt = Math.min(0.033, (ts - lastTime) / 1000 || 0.016);
        lastTime = ts;
        update(dt);
        render();
        requestAnimationFrame(loop);
      }

      function resizeCanvas(){
        const shell = document.querySelector(".game-shell");
        const ratio = W / H;
        const w = shell.clientWidth;
        const h = shell.clientHeight;
        const currentRatio = w / h;
        if(currentRatio > ratio){
          canvas.style.width = `${h * ratio}px`;
          canvas.style.height = `${h}px`;
        }else{
          canvas.style.width = `${w}px`;
          canvas.style.height = `${w / ratio}px`;
        }
      }

      function startGame(){
        audio.init();
        audio.click();
        ui.menu.classList.add("hidden");
        resetGame();
      }

      function backToMenu(){
        hideAllOverlays();
        game.running = false;
        game.paused = false;
        game.state = "menu";
        ui.hud.classList.add("hidden");
        ui.menu.classList.remove("hidden");
        clear();
      }

      window.addEventListener("keydown", e => {
        keys[e.code] = true;
        if(["ArrowUp","ArrowDown","ArrowLeft","ArrowRight","Space"].includes(e.code)) e.preventDefault();

        if(e.code === "Escape" && game.state === "playing"){
          togglePause();
        }
      });

      window.addEventListener("keyup", e => {
        keys[e.code] = false;
      });

      ui.playBtn.addEventListener("click", startGame);
      ui.pauseBtn.addEventListener("click", () => togglePause(true));
      ui.resumeBtn.addEventListener("click", () => togglePause(false));
      ui.restartBtn.addEventListener("click", () => { audio.init(); audio.click(); hideAllOverlays(); resetGame(); });
      ui.retryBtn.addEventListener("click", () => { audio.init(); audio.click(); hideAllOverlays(); resetGame(); });
      ui.playAgainBtn.addEventListener("click", () => { audio.init(); audio.click(); hideAllOverlays(); resetGame(); });
      ui.backMenuBtn1.addEventListener("click", () => { audio.init(); audio.click(); backToMenu(); });
      ui.backMenuBtn2.addEventListener("click", () => { audio.init(); audio.click(); backToMenu(); });

      window.addEventListener("resize", resizeCanvas);

      // Inicialização
      resizeCanvas();
      requestAnimationFrame(loop);

      // Desenha fundo simples no canvas enquanto o menu está ativo
      function idleMenuCanvas(){
        if(game.state !== "menu") return;
        ctx.fillStyle = "#000";
        ctx.fillRect(0,0,W,H);
        requestAnimationFrame(idleMenuCanvas);
      }
      idleMenuCanvas();
    })();
  