# O Último Guardião

Jogo em HTML/JS, arquivo único e autocontido.

## Como jogar
Basta abrir o `index.html` no navegador, ou publicar via GitHub Pages:

1. Suba este repositório no GitHub.
2. Vá em **Settings > Pages**.
3. Em "Branch", selecione `main` e a pasta `/ (root)`.
4. Salve — o jogo ficará disponível em `https://SEU-USUARIO.github.io/NOME-DO-REPO/`.
